"""
WARNING:

Please make sure you install the bot with `pip install -e .` in order to get all the dependencies
on your Python environment.

Also, if you are using PyCharm or another IDE, make sure that you use the SAME Python interpreter
as your IDE.

If you get an error like:
```
ModuleNotFoundError: No module named 'botcity'
```

This means that you are likely using a different Python interpreter than the one used to install the bot.
To fix this, you can either:
- Use the same interpreter as your IDE and install your bot with `pip install -e .`
- Use the same interpreter as the one used to install the bot (`pip install -e .`)

Please refer to the documentation for more information at https://documentation.botcity.dev/
"""
import xml.etree.ElementTree as ET
import pandas as pd
from botcity.core import DesktopBot
# Uncomment the line below for integrations with BotMaestro
# Using the Maestro SDK
# from botcity.maestro import *

class Dados():
    def pandas_dados(self):
        self.dados_df = pd.read_excel("Dados.xlsx")
        self.dti = f'{self.dados_df.loc[1, "data_in"]:%d/%m/%Y}'
        self.dtf = f'{self.dados_df.loc[1, "data_fim"]:%d/%m/%Y}'
        self.resumo = ' NFSE RESUMO '
        self.talao = ' NFSE '
        self.xsai = ' XML SAIDAS '
        self.xent = ' XML ENTRADAS '
        self.exten = '.xml'
        self.barra = "\\"
        self.linkConsultas="https://nfse.recife.pe.gov.br/contribuinte/consultas.aspx"
        self.linkTalao="https://nfse.recife.pe.gov.br/contribuinte/tfe.aspx"
        print(self.dados_df)


class Bot(DesktopBot, Dados):
    def action(self, execution=None):
        self.login_inicial()
        self.browse("https://nfse.recife.pe.gov.br/senhaweb/login.aspx")
        self.certificado()
        self.pandas_dados()


    def login_inicial(self):
       self.browse("https://nfse.recife.pe.gov.br/senhaweb/login.aspx")
       



    def sessao_expirou(self):   
        if not self.find( "acessarSistema", matching=0.97, waiting_time=10000):
            self.not_found("acessarSistema")
        self.click()


    def not_found(self, label):
        print(f"Element not found: {label}")


if __name__ == '__main__':
    Bot.main()
